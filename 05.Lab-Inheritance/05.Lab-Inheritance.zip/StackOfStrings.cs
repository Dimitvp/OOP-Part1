﻿
using System.Collections.Generic;

class StackOfStrings
{
    private List<string> data;

    public StackOfStrings()
    {
        this.data = new List<string>();
    }

    public void Push(string item)
    {
        // Push
    }

    public string Pop()
    {
        // Pop
        return "not inplemented!";
    }

    public string Peek()
    {
        // Pop
        return "not inplemented!";
    }

    public bool IsEmpty()
    {
        // Pop
        return false;
    }

}



//•	Private field: data: List<string>
//•	Public method: Push(string item): void
//•	Public method: Pop(): string
//•	Public method: Peek(): string
//•	Public method: IsEmpty(): bool
