﻿public abstract class FoodFactory
{
    public abstract int Points { get; }
}