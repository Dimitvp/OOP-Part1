﻿class HoneyCake : FoodFactory
{
    public override int Points => 5;
}