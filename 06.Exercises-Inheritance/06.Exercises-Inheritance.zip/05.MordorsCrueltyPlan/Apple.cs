﻿class Apple : FoodFactory
{
    public override int Points => 1;
}