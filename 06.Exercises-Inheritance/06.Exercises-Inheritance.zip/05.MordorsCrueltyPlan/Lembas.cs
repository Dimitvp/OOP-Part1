﻿class Lembas : FoodFactory
{
    public override int Points => 3;
}