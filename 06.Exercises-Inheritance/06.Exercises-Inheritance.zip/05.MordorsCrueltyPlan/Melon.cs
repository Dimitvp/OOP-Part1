﻿class Melon : FoodFactory
{
    public override int Points => 1;
}