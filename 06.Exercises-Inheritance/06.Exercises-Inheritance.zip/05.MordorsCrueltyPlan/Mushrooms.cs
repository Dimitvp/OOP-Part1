﻿class Mushrooms : FoodFactory
{
    public override int Points => -10;
}