﻿class Cram : FoodFactory
{
    public override int Points => 2;
}