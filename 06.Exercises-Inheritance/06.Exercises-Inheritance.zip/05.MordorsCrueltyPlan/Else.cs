﻿class Else : FoodFactory
{
    public override int Points => -1;
}