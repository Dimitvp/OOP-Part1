﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using _02.Exercises_DefiningClasses.Google;

namespace _02.Exercises_DefiningClasses
{
    class Startup
    {
        static void Main(string[] args)
        {


            #region Problem 15.	*Drawing tool
            string figure = Console.ReadLine();
            if (figure == "Square")
            {
                int width = int.Parse(Console.ReadLine());
                CorDraw.Draw(figure, width);
            }
            else
            {
                int width = int.Parse(Console.ReadLine());
                int height = int.Parse(Console.ReadLine());

                CorDraw.Draw(figure, width, height);
            }

            #endregion


        }

        #region Problem 14.	*Cat Lady - Methods
        private static void AddCats(List<Siamese> siCatList, List<Cymric> cyCatList, List<StreetExtraordinaire> stCatList, string[] commands)
        {
            switch (commands[0])
            {
                case "Siamese"://•	“Siamese < name > < earSize >”
                    Siamese SiCat = new Siamese(commands[1], double.Parse(commands[2]));
                    siCatList.Add(SiCat);
                    break;
                case "Cymric"://•	“Cymric < name > < furLength >”
                    Cymric CyCat = new Cymric(commands[1], double.Parse(commands[2]));
                    cyCatList.Add(CyCat);
                    break;
                case "StreetExtraordinaire"://•	“StreetExtraordinaire < name > < decibelsOfMeows >”
                    StreetExtraordinaire StCat = new StreetExtraordinaire(commands[1], double.Parse(commands[2]));
                    stCatList.Add(StCat);
                    break;
            }
        }

        private static void PrintCat(string command, List<Siamese> siCatList, List<Cymric> cyCatList, List<StreetExtraordinaire> stCatList)
        {
            if (siCatList.Count > 0)
            {
                var cat = siCatList.FirstOrDefault(x => x.Name == command);

                if (cat != null)
                {
                    Console.WriteLine(cat.ToString());
                }
            }

            if (cyCatList.Count > 0)
            {

                var cat = cyCatList.FirstOrDefault(x => x.Name == command);
                if (cat != null)
                {
                    Console.WriteLine(cat.ToString());

                }
            }

            if (stCatList.Count > 0)
            {
                var cat = stCatList.FirstOrDefault(x => x.Name == command);
                if (cat != null)
                {
                    Console.WriteLine(cat.ToString());
                }
            }
        }
        #endregion

        #region Problem 13.	Family Tree - Methods
        private static void CreateFamily(List<Person> familyMembers, List<string> commandHistory, List<string> treeCommands)
        {
            foreach (string command in commandHistory)
            {
                if (!command.Contains("-"))
                {
                    // person data
                    AddFamilyMembers(familyMembers, command);
                }
                else
                {
                    // relationships data
                    treeCommands.Add(command);
                }
            }
        }

        private static void PrintResult(string fisrCommand, List<Person> familyMembers)
        {
            if (fisrCommand != null)
            {
                Person resulPerson;
                if (fisrCommand.Contains("/"))
                {
                    //find by date
                    resulPerson = familyMembers.Find(x => x.DateOfBirth == fisrCommand);
                }
                else
                {
                    //find by name
                    resulPerson = familyMembers.Find(x => x.Name == fisrCommand);
                }

                Console.WriteLine($"{resulPerson.Name} {resulPerson.DateOfBirth}");
                Console.WriteLine("Parents:");
                if (resulPerson.Parents.Count > 0)
                {

                    resulPerson.Parents.ForEach(x => Console.WriteLine($"{x.Name} {x.DateOfBirth}"));
                }
                Console.WriteLine("Children:");

                if (resulPerson.Childs.Count > 0)
                {
                    resulPerson.Childs.ForEach(x => Console.WriteLine($"{x.Name} {x.DateOfBirth}"));
                }

            }
        }

        private static void PopulateRelationships(List<Person> familyMembers, List<string> treeCommands)
        {
            foreach (var comm in treeCommands)
            {
                string[] commands = comm.Split(new string[] { " - " }, StringSplitOptions.RemoveEmptyEntries).ToArray();
                if (commands[0].Contains("/"))
                {
                    // <date> <???>
                    if (commands[1].Contains("/"))
                    {
                        // <date> <date>
                        Person parent = familyMembers.First(x => x.DateOfBirth == commands[0]);
                        Person child = familyMembers.First(x => x.DateOfBirth == commands[1]);

                        parent.Childs.Add(child);
                        child.Parents.Add(parent);
                    }
                    else
                    {
                        // <date> <name>
                        Person parent = familyMembers.First(x => x.DateOfBirth == commands[0]);
                        Person child = familyMembers.First(x => x.Name == commands[1]);

                        parent.Childs.Add(child);
                        child.Parents.Add(parent);
                    }
                }
                else
                {
                    // <name> <???>
                    if (commands[1].Contains("/"))
                    {
                        // <name> <date>
                        Person parent = familyMembers.First(x => x.Name == commands[0]);
                        Person child = familyMembers.First(x => x.DateOfBirth == commands[1]);

                        parent.Childs.Add(child);
                        child.Parents.Add(parent);
                    }
                    else
                    {
                        // <name> <name>
                        Person parent = familyMembers.First(x => x.Name == commands[0]);
                        Person child = familyMembers.First(x => x.Name == commands[1]);

                        parent.Childs.Add(child);
                        child.Parents.Add(parent);
                    }
                }

            }
        }

        private static void AddFamilyMembers(List<Person> persons, string command)
        {
            string[] commands = command.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).ToArray();
            string name = commands[0] + " " + commands[1];
            Person person = new Person(name, commands[2]);
            persons.Add(person);
        }

        private static string CreateHistory(string input, List<string> history)
        {
            while (input != "End")
            {
                history.Add(input);
                input = Console.ReadLine();
            }

            return input;
        }
        #endregion
    }
}



